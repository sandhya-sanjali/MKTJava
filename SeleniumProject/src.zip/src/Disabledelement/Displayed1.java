package Disabledelement;

public class Displayed1
{
	public static void main(String[] args) 
	{
		
	}

}
