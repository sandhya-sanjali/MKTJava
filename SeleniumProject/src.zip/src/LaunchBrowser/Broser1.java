package LaunchBrowser;

import org.openqa.selenium.chrome.ChromeDriver;

public class Broser1 
{
	public static void main(String[] args) 
	{
		ChromeDriver d1=new ChromeDriver();
	}

}
