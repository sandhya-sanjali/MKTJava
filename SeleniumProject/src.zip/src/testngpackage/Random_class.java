package testngpackage;

public class Random_class 
{
	//run a random method using for loop for 1000 times
	public static void main(String[] args) 
	{
		int i;
	for (i=0;i<=1000;i++)
	{
		System.out.println(Math.random());
		
		
	}

}}
