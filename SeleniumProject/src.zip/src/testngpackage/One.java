package testngpackage;

import org.testng.annotations.Test;

public class One
{
	@Test
	public void testcase1()
	{
		
	}
}
