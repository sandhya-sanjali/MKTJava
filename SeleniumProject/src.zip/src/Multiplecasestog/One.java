package Multiplecasestog;

import org.testng.annotations.Test;

public class One 
{
	@Test
	public void testcase1()
	{
		System.out.println("1");
	}
}
