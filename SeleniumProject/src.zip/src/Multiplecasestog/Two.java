package Multiplecasestog;

import org.testng.annotations.Test;

public class Two {

	@Test
	public void testcase2()
	{
		System.out.println("2");
	}
}


