package Multiplecasestog;

import org.testng.annotations.Test;

public class Four {

	@Test
	public void testcase4()
	{
		System.out.println("4");
	}
}


