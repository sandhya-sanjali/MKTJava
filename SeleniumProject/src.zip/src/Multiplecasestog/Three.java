package Multiplecasestog;

import org.testng.annotations.Test;

public class Three {

	@Test
	public void testcase3()
	{
		System.out.println("3");
	}
}


