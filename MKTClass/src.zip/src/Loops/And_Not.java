package Loops;

public class And_Not 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		
		if(!(a==b && a<b))
		{
			System.out.println("India");
		}

	}

}
