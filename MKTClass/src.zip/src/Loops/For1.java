package Loops;

public class For1 
{

	public static void main(String[] args) 
	{
		for(int i=5;i<1;i--)
		{
			System.out.println("Hello");
		}

	}

}
