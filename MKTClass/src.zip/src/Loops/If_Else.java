package Loops;

public class If_Else 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		if (a==b)
		{
			System.out.println("A is greater");
		}
		if (a<b)
		{
			System.out.println("B is greater");
		}

	}

}
