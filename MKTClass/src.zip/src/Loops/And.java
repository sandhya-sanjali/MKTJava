package Loops;

public class And 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		
		if (a>5 && b==20)
		{
			System.out.println("1");
		}
		else
		{
			System.out.println("2");
		}
	}

}
