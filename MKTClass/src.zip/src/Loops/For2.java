package Loops;

public class For2 
{

	public static void main(String[] args) 
	{
		for(int i=5;i>1;i++)//infinite loop
		{
			System.out.println("Hello");
		}

	}

}
