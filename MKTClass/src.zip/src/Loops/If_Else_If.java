package Loops;

public class If_Else_If 
{

	public static void main(String[] args) 
	{
		int a=100;
		int b=200;
		
		if(a>b)
		{
			System.out.println("1");
		}
		else if(a==b)
		{
			System.out.println("2");
		}
		else 
		{
			System.out.println("3");
		}
				

	}

}
