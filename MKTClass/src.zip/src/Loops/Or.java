package Loops;

public class Or 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=30;
		
		if (a==b || a!=b)
		{
			System.out.println("1");
		}
		else
		{
			System.out.println("2");
		}

	}

}
