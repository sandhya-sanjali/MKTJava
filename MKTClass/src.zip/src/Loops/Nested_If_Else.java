package Loops;

public class Nested_If_Else 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		int c=30;
		
		if (a==c)
		{
			if (a==b)
			{
				System.out.println("Hello");
			}
			else
			{
				System.out.println("Hi");
			}
	
			
		}
		else
		{
			System.out.println("Bye-Bye");
		}
		

	}

}
