package Accessspecifierwithinpackage;

public class Teacher 
{
	public void add()
	{
		System.out.println("1");
	}
	private void substract()
	{
		System.out.println("2");	
	}
	protected void multiplicatio() 
	{
		System.out.println("3");
	}
	void divide() 
	{
		System.out.println("4");
	}

}
