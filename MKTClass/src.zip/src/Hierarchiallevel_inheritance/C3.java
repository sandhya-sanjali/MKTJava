package Hierarchiallevel_inheritance;

public class C3 extends Parent
{
	void upiid()
	{
		System.out.println("upi id");
	}

	public static void main(String[] args)
	{
		C3 c=new C3();
		c.upiid();
		c.login();
		
	}

}
