package Hierarchiallevel_inheritance;

public class C1 extends Parent
{
	void cod()
	{
		System.out.println("cash on delivery");
	}

	public static void main(String[] args)
	{
		C1 c=new C1();
		c.cod();
		c.login();
		
	}

}
