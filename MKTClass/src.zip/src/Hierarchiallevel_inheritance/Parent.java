package Hierarchiallevel_inheritance;

public class Parent 
{
	void login()
	{
		System.out.println("login");
	}

	

}
