package Assignments;

public class NonstaticRam {
	
	
	

	public static void main(String[] args) {
		
		int monthly_salary	= 2000;
		int yearly_salary = monthly_salary*12;
		int charity = (yearly_salary*10)/100;
		System.out.println(charity);
		System.out.println(yearly_salary);
	}

}
