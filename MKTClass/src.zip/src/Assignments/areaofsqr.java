package Assignments;

public class areaofsqr 
{	
	int a=5;

	public static void main(String[] args) 
	{
		areaofsqr a1=new areaofsqr();
		int area =(a1.a*a1.a);
		System.out.println(area);
	}

}
