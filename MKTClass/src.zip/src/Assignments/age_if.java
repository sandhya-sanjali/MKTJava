package Assignments;

public class age_if 
{

	public static void main(String[] args) 
	{
		int a=92;
		
		if(a<18)
		{
			System.out.println("a is younger");
			
		}
		else if(a>=60)
		{
				System.out.println("a is Sr. Citizen");
		}

	}

}
