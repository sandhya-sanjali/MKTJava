package Assignments;

public class And3 {

	public static void main(String[] args)
	{
		for(int i=9;i<=90;i++)
		{
			System.out.println(i);
		}

	}

}
