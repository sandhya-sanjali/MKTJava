package Assignments;

public class datatypespractise6thjuly1 {

	public static void main(String[] args)
	{
	int ram_monthly_salary=2000;
	int yearly_salary= ram_monthly_salary*12;
	int charity=(yearly_salary*10)/100;
	System.out.println(yearly_salary);
	System.out.println(charity);
	}

}
