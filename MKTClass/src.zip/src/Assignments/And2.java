package Assignments;

public class And2 {

	public static void main(String[] args) 
	{
		for(int i=-50;i<=-41;i++)
		{
			System.out.println(i);
		}

	}

}
