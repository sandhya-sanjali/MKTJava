package Assignments;

public class areaofcircle 
{
	public static void main(String[] args) 
	{
		int r=7;
		double area =(pi*r*r);
		System.out.println(area);
		
	}

	static double pi=3.14;
		


}
