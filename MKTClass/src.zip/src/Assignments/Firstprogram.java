package Assignments;

public class Firstprogram 
{

	public static void main(String[] args) 
	{
	System.out.println("Hey, we did it, this is my first program");	
	System.out.println("Sandhya");
	}

}
