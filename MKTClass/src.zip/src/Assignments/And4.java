package Assignments;

public class And4 {

	public static void main(String[] args) 
	{
		for(int i=0;i>1;i++)
		{
		System.out.println(i);	
		}
		for(int j=-1;j>0;j--)
		{
			System.out.println(j);
		}

	}

}
