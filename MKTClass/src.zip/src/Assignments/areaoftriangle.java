package Assignments;

public class areaoftriangle 
{
	static int a=4;
	int b=5;

	public static void main(String[] args) 
	{
		areaoftriangle a1=new areaoftriangle();
		double area =(1.0/2.0)*a*a1.b;
		System.out.println(area);
		
	}

}
