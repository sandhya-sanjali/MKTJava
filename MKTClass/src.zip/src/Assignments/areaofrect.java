package Assignments;

public class areaofrect 
{	
	 int a=5;
	 int b=6;

	public static void main(String[] args) 
	{
		areaofrect a1=new areaofrect();
		int area =(a1.a*a1.b);
		System.out.println(area);

	}

}
