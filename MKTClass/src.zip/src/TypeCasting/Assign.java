//convert byte into long - widening

package TypeCasting;

public class Assign 
{
	public static void main(String[] args) 
	{
		byte number=100;
		long number1= (long)number;
		System.out.println(number1);
	}

}
