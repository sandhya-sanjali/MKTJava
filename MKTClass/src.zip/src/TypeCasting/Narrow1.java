//convert double into int

package TypeCasting;

public class Narrow1 
{
	public static void main(String[] args) 
	{
		double weight =55.5;
		int weight1= (int) weight;
		System.out.println(weight1);
		
		double weight2=54.5;
		int weight3= (int)weight2;
		System.out.println(weight3);
		
	}

}
