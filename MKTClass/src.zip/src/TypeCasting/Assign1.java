//convert long into byte - narrowing

package TypeCasting;

public class Assign1 
{
	public static void main(String[] args)
	{
		long number=-100;
		byte number1= (byte)number;
		System.out.println(number1);
	}

}
