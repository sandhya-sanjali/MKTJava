package Package2;

public class Teacher 
{
	private void java1()
	{
		
	}
	public void selenium()
	{
		
	}
	protected void apitesting()
	{
		
	}
	void sql()
	{
		
	}
	
	

}
