package javaclass;

public class And1 
{

	public static void main(String[] args) 
	{
		int a=20;
		int b=100;
		
		if(a==b && b>20)
		{
			System.out.println("Sandhya");
		}
		else
		{
			System.out.println("Surendra");
		}
	}

}
