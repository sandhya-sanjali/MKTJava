package javaclass;

public class corejava {

	public static void add(Integer i, Integer j) {
		System.out.println(i+j);
	}

	public static void main(String[] args) {

		System.out.println("one");
		{

			System.out.println("Hey, i did it");
			System.out.println("sandhya, i love u");

		}
		
		add(2,3);
	}
}