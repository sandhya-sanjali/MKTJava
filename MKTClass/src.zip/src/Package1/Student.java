package Package1;

import Package2.Teacher;

public class Student
{
	

	public static void main(String[] args) 
	{
		Teacher t=new Teacher();
		t.selenium();

	}

}
//outside the package without becoming subclass, u can access only public