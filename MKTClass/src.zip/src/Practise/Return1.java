package Practise;

public class Return1 
{
	static int addition(int a, int b)
	{
		int c=a+b;
		return c;
	}
	public static void main(String[] args) 
	{
		addition(17,43);

	}

}
