package Practise;

public class StringDemo2 
{

	public static void main(String[] args) 
	{
		String b="12 Dec 2021";
		{
			System.out.println(b.substring(0, 2));
			System.out.println(b.substring(3, 7));
			System.out.println(b.substring(7));
			
		}
	}

}
