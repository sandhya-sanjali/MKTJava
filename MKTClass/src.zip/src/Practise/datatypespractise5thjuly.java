package Practise;

public class datatypespractise5thjuly {

	public static void main(String[] args)
	{
	byte a=12;
	System.out.println(a);
	short b=124;
	System.out.println(b);
	int c=9876;
	System.out.println(c);
	long d = 987653;
	System.out.println(d);
	float e=9876.65f;
	System.out.println(e);
	double f = 4.23;
	System.out.println(f);
	char a1='I';
	System.out.println(a1);
	boolean a2=true;
	System.out.println(a2);
	boolean a3=false;
	System.out.println(a3);
	String a4="sandhya";
		System.out.println(a4);

	}

}
