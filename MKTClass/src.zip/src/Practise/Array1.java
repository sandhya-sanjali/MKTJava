package Practise;

public class Array1 
{

	public static void main(String[] args) 
	{
		String [] god=new String[5];
		god[0]="Ram";
		god[1]="Laxman";
		god[2]="Shiv";
		god[3]="parvati";
		god[4]="sita";
		
		System.out.println(god[0]);
		
		for(int i=0;i<=5;i++)
		{
			System.out.println(god[0]);
		}
		
		for(int i=0;i<=4;i++)
		{
			System.out.println(god[i]);
		}
	}

}
