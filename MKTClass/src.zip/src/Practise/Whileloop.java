package Practise;

public class Whileloop 
{

	public static void main(String[] args) 
	{
		int i; i=1;
		while(i<3)
		{
			int a=10; int b=20; int c=a+b;
			System.out.println(c);
			i++;
		}
		
		int a=10;
		while (a>6)
		{
			int b=20;
			int c=b+20;
			System.out.println(c);
			a--;
		}
	}
	
}
