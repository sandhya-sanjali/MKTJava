package Practise;

public class secondprogram {

	
	static void add()
	{
		System.out.println("addition");
	}
	
	static void substract ()
	{
		System.out.println("substraction");
	}
	
	static void multiple ()
	
	{
		System.out.println("multiplication");
	}
	
	static void divide ()
	
	{
		System.out.println("division");
	}
	
	
	public static void main(String[] args) 
	{
		System.out.println("Hi, i am starting");
		add();
		substract();multiple();divide();
		multiple();
		divide();
	}
	}


