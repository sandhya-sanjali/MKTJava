package Practise;

public class Iib 
{
	{
		System.out.println("I am IIB");
	}

	public static void main(String[] args) 
	{
		System.out.println("I am Main Method");//IIb will be called after u create an object
		new Iib();

	}

}
