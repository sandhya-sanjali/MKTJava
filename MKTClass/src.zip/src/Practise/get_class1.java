package Practise;

public class get_class1
{
	public static void main(String[] args)
	{
		get_class1 g1=new get_class1();
		System.out.println(g1.getClass());
	}

}
