package Practise;

public class Sib 
{


	public static void main(String[] args) 
	{
		System.out.println("I am Main Method");

	}
	static
	{
		System.out.println("Hi, I am SIB");//SIB will be called automatically before main method
	}

}
