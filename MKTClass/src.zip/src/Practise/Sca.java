package Practise;

import java.util.Scanner;

public class Sca 
{

	public static void main(String[] args) 
	{
		Scanner s1=new Scanner(System.in);
		int a1=s1.nextInt();
		int a2=s1.nextInt();
		s1.close();
		int c=a1+a2;
		System.out.println(c);

	}

}
