package Practise;
public class Notoperator 
{
	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		if(!(a>b && b==6))
		{
			System.out.println("If Block");
		}
		
		
		
	}

}
