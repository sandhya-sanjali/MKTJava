package Practise;

public class Acessspecifier_Package
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
