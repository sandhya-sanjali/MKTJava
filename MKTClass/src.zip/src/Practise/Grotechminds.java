package Practise;
interface Login
{
	void un();//abstract method
}
public class Grotechminds implements Login

{

	public static void main(String[] args) 
	{
		
	}

	@Override
	public void un() //concrete overriding
	{
		
	}

}
