package Practise;

public class Local_varaible 
{
	void add()
	{
		int b=100;
		System.out.println(b);
	}
	
	public static void main(String[] args)
	{
		int a=10;
		System.out.println(a);
		a=100; //updating the value
		System.out.println(a);
		/*String b;
		System.out.println(b);*/ //string b is not initialized so on executing it throws error
	}











}

