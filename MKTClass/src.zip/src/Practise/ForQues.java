package Practise;

public class ForQues 
{

	public static void main(String[] args) 
	{
		for(int i=-5;i<=0;i++)
		{
			System.out.println(i);
		}
		
		for(int i=1;i<=100;i++)
		{
			System.out.println(i);
		}
		
		for(int i=-50;i<=-41;i++)
		{
			System.out.println(i);
		}
		
		for(int i=9;i<=90;i++)
		{
			System.out.println(i);
		}
	}

}
