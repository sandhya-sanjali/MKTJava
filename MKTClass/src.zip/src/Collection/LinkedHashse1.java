package Collection;

import java.util.LinkedHashSet;

public class LinkedHashse1 
{
	public static void main(String[] args) 
	{
		LinkedHashSet lh1= new LinkedHashSet();
		lh1.add("sandhya");
		lh1.add(58);
		lh1.add(5.2);
		lh1.add("Sandhya Surendra");
		lh1.add("sandhya");
		lh1.add(null);
		System.out.println(lh1);
		
		LinkedHashSet lh2= new LinkedHashSet();
		lh2.add(5678);
		lh2.add(234);
		lh2.add(7896);
		lh2.add(23);
		lh2.add(67899);
		lh2.add(2);
		System.out.println(lh2);
		
		
	}

}
