package Collection;

import java.util.TreeSet;

public class Treese1 {
	

	public static void main(String[] args) 
	{
		TreeSet t1=new TreeSet();
		t1.add("sandhya");
	//	t1.add(58);
	//	t1.add(5.2);
	//	t1.add('F');
		t1.add("sandhya Surendra");
	//	t1.add(null);
		t1.add("sandhya");
		System.out.println(t1);
		
		TreeSet t2=new TreeSet();
		t2.add(5);
		t2.add(67);
		t2.add(43);
		t2.add(2);
		System.out.println(t2);
	}

}
