package Constructor;

public class Constructor1 
{
	{
		System.out.println("I live in India");
	}
	public static void main(String[] args) 
	{
		Constructor1 c1=new Constructor1();
		System.out.println("Hi, I am main Method");
		new Constructor1();

	}

}
