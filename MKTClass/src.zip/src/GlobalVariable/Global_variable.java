package GlobalVariable;

public class Global_variable 
{
	static int a=10;//global variable
	double wt=55.55;
	static int myweight=100;// any global variable can be declared and utilized
	void add()  //default value of a global variable is 0, so output is 0
	{
		//assigned value 100 here as i can declare any value later and output is 100
	}

	public static void main(String[] args) 
	{
		System.out.println(myweight);

	}

}
