package GlobalVariable;

public class Global_variable1 
{
	static int a=10;
	void add()
	{
		System.out.println(a);
	}

	public static void main(String[] args)
	{
		a=100;
	
		System.out.println(a);
		Global_variable1 g1=new Global_variable1();
		g1.add();

	}

}
