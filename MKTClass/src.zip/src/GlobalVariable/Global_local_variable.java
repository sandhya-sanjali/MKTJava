package GlobalVariable;

public class Global_local_variable
{
	 static double pi=3.14;

	public static void main(String[] args) 
	{
		pi=89;
		final int a=100;
		System.out.println(a);
		System.out.println(pi);
		
	
	}

}
